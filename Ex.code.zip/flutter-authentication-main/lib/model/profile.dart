class Profile{
  String email;
  String password;

  Profile({this.email,this.password});
}